from flask_wtf import FlaskForm
from wtforms import StringField, SelectField, BooleanField, SubmitField
from wtforms.validators import DataRequired, Length


choices = [
    "Seattle",
    "San Francisco",
    "Los Angeles",
    "Phoenix",
    "Denver",
    "Kansas City",
    "Houston",
    "Chicago",
    "Nashville",
    "New York",
    "Washington D.C.",
    "Miami",
]


class Shipping_Form(FlaskForm):

    sender = StringField("Sender", validators=[DataRequired()])
    recipient = StringField("Recipient", validators=[DataRequired()])
    origin = SelectField("Orign", choices=choices, validators=[DataRequired()])
    destination = SelectField(
        "Destination", choices=choices, validators=[DataRequired()]
    )
    express_enabled = BooleanField(
        "Express Shipping", validators=[DataRequired()], default=True
    )
    submit = SubmitField("Submit New Package Order")
