# imports
from flask import Flask, render_template, redirect
from .config import Config
from .forms import Shipping_Form
from .models import db, Package
from flask_migrate import Migrate
from map.map import advance_delivery

# set up
app = Flask(__name__)
app.config.from_object(Config)
# hook up models
db.init_app(app)

# automatically create migrations

Migrate(app, db)


# routes


# home page showing our list of in-progrss packages
@app.route("/")
def index():
    packages = Package.query.all()
    # packages.reverse()
    return render_template("index.html", packages=packages)


# Creates the new package / Gets the new package form
@app.route("/new_package", methods=["GET", "POST"])
def add_package():
    form = Shipping_Form()
    if form.validate_on_submit():
        print(form.data)
        # from the data, make a new package
        new_package = Package(
            name=form.data["sender"],
            recipient=form.data["recipient"],
            origin=form.data["origin"],
            destination=form.data["destination"],
            location=form.data["origin"],
        )

        # add the new Package to the database
        db.session.add(new_package)  # adds to the database
        db.session.commit()  # commits our changes
        return redirect("/")

    return render_template("shipping_request.html", form=form)


# route to handle the passage of time
@app.route("/pass_time")
def pass_time():
    # get all the packages
    packages = Package.query.all()
    # for each package, advance the time
    for package in packages:
        update_location = advance_delivery(package.location, package.destination)
        # updating the class instance
        package.location = update_location

    # commits all the changes
    db.session.commit()
    return redirect("/")
