# map = {
#     "Seattle": {"San Francisco", "Washington D.C."},
#     "San Francisco": {"Seattle", "Los Angeles", "Denver"},
#     "Los Angeles": {"San Francisco", "Phoenix"},
#     "Phoenix": {"Los Angeles", "Denver"},
#     "Denver": {"Phoenix", "San Francisco", "Houston", "Kansas City"},
#     "Kansas City": {"Denver", "Houston", "Chicago", "Nashville"},
#     "Houston": {"Kansas City", "Denver"},
#     "Chicago": {"Kansas City", "New York"},
#     "Nashville": {"Kansas City", "Houston", "Miami"},
#     "New York": {"Chicago", "Washington D.C."},
#     "Washington D.C.": {"Chicago", "Nashville", "Miami", "Seattle"},
#     "Miami": {"Washington D.C.", "Houston", "Nashville"},
# }


# print(map.keys())
